package addon;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.chrono.Chronology;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalQueries;
import java.time.temporal.TemporalUnit;

public class QueryExample {

    public static void main (String... args) {
        LocalTime t = LocalTime.of(20, 10, 20, 5000);
        processQueries(t);
        
        LocalDateTime ldt = LocalDateTime.now();
        processQueries(ldt);
        
        ZonedDateTime zdt = ZonedDateTime.now();
        processQueries(zdt);
    }

    private static void processQueries(Temporal t)
    {
        TemporalUnit a = t.query(TemporalQueries.precision());
        System.out.printf("precision: %s%n", a);

        LocalTime t2 = t.query(TemporalQueries.localTime());
        System.out.printf("localTime: %s%n", t2);


        LocalDate d = t.query(TemporalQueries.localDate());
        System.out.printf("localDate: %s%n", d);

        ZoneOffset o = t.query(TemporalQueries.offset());
        System.out.printf("ZoneOffset: %s%n", o);

        ZoneId z = t.query(TemporalQueries.zone());
        System.out.printf("zone: %s%n", z);

        ZoneId i = t.query(TemporalQueries.zoneId());
        System.out.printf("zoneId: %s%n", i);

        Chronology c = t.query(TemporalQueries.chronology());
        System.out.printf("chronology: %s%n", c);
    }
}