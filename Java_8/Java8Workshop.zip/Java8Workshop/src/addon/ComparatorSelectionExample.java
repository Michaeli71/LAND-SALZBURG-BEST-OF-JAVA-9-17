package addon;

public class ComparatorSelectionExample
{
/*
    public static void main(String[] args)
    {
        Comparator<Person> byName = null;
        Comparator<Person> byAge = null;
        Comparator<Person> byCity = null;

        
        Map<String, Comparator<Person>> compNameMapping = new HashMap<>();
        compNameMapping.put("BY_NAME", byName);
        compNameMapping.put("BY_AGE", byAge);
        
        
        Comparator<Person> comp = compNameMapping.getOrDefault("key", byCity);
        listPerons.sort(comp);
    }

    static class Person
    {
        
    }
    */
}
