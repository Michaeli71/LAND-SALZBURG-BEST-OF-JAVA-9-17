package addon;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.Month;

import org.junit.jupiter.api.Test;

public class HurricaneSeasonQueryTest
{
    @Test
    public void is_during_hurricane_season()
    {

        LocalDate date = LocalDate.of(2014, Month.JUNE, 30);

        Boolean isHurricaneSeason = date.query(new HurricaneSeasonQuery());

        assertTrue(isHurricaneSeason);
    }
    
    
    @Test
    public void is_during_hurricane_season_feb()
    {

        LocalDate date = LocalDate.of(2014, Month.FEBRUARY, 7);

        Boolean isHurricaneSeason = date.query(new HurricaneSeasonQuery());

        assertFalse(isHurricaneSeason);
    }
}
