package addon;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class LambdaWithParametersExample
{
    public static void main(String[] args)
    {
        Predicate<Integer> inRange100_1000 = n -> n > 100 && n < 1000;
        
        Predicate<Integer> inRange = inRange(100, 1000);
        List<Integer> result = Stream.of(10, 500, 200, 30, 700, 1000, 777).filter(inRange(100, 1000)).collect(Collectors.toList());
        System.out.println(result);     
        
        System.out.println(isInRange(50, 10, 100));
    }

    private static boolean isInRange(int n, int lower, int upper)
    {
        return n > lower && n < upper;
    }
    
    private static Predicate<Integer> inRange(int lower, int upper)
    {
        return n -> n > lower && n < upper;
    }
}
