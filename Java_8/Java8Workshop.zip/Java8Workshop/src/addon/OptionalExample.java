package addon;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class OptionalExample
{

    public static void main(String[] args)
    {
        Optional<Customer> optCustomer = findCustomer(false);
        
        if (optCustomer.isPresent())
        {
            processCustomerOldStyle(optCustomer.get());
        }
//        else
        {
            // handleNoCustomer
        }        
    }

    
    private static void processCustomerOldStyle(Customer customer)
    {
        Objects.requireNonNull(customer);        

        // Ab hier alles sicher
        System.out.println(customer.getBirthday().getYear());        
        System.out.println(customer.getName().length());
    }


    private static Customer findCustomerOldStyle(boolean found)
    {
        // Aufwändige Suche ...
        if (found)
            return new Customer("Peter", LocalDate.now());
        
        // nichts gefunden
        return null;
    }

    private static Optional<Customer> findCustomer(boolean found)
    {
        // Aufwändige Suche ...
        if (found)
            return Optional.of(new Customer("Peter", LocalDate.now()));
        
        // nichts gefunden
        return Optional.empty();
    }

    
    // BEST PRACTISE
    private static List<Customer> findCustomersByCondition()
    {
        // Aufwändige Suche ...
        
        // nichts gefunden
        //return null; // NEIN
        return Collections.emptyList();
    }
    
    static class Customer
    {
        String name;
        LocalDate birthday;
        //
        
        // NEVER
        public Customer()
        {            
        }
        
        public Customer(String name, LocalDate birthday)
        {
            this.name = name;
            this.birthday = birthday;
        }

        public String getName()
        {
            return name;
        }

        public void setName(String name)
        {
            this.name = name;
        }

        public LocalDate getBirthday()
        {
            return birthday;
        }

        public void setBirthday(LocalDate birthday)
        {
            this.birthday = birthday;
        }
        
    }
}
