package addon;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class StreamLambdaExample
{
    @FunctionalInterface
    interface MyCon
    {
        void doSomething(Object obj);
    }

    public static void main(String[] args)
    {
        Stream<Integer> numbers = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 15, 16, 17, 18, 19, 20);

        Predicate<Integer> isEven = i -> i % 2 == 0;

        numbers.filter(isEven).filter(isInRange(5, 11).or(isInRange(15, 19))).forEach(num -> System.out.println(num));

        // -- eigenes Functional Interface im Einsatz
        MyCon myConsumer = obj -> System.out.println(obj);
        MyCon myConsumerAsClass = new MyCon()
        {
            @Override
            public void doSomething(Object obj)
            {
                System.out.println(obj);
            }
        };

        List<Integer> numbers2 = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        processNumbers(numbers2, obj -> System.out.println(obj));
    }

    private static void processNumbers(List<Integer> numbers, MyCon consumer)
    {
        for (Integer val : numbers)
        {
            consumer.doSomething(val);
        }
    }

    private static Predicate<Integer> isInRange(int lower, int upper)
    {
        return i -> i > lower && i < upper;
    }

    /*
     *         Consumer<Integer> action = System.out::println;
        MyCon myConsumer = System.out::println;
        
        // Consumer<Integer> action2 = num -> System.out.println(num);
        BiConsumer<Integer, String> action3 = (a,b) -> System.out.println(a + b);
        
        //Object lambda = (a,b) -> System.out.println(a + b);
        //BiConsumer<Integer, String> action4 = System.out::println;
    
     */
}
