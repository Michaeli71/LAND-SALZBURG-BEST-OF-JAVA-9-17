package addon;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamExample
{
    public static void main(String[] args)
    {
          Stream<String> names = Stream.of("Tim", "Tom", "Peter", "Mike", "Thomas");
          
          Stream<String> startsWithT = names.peek(str -> System.out.println("Processing: " + str)).
                                             filter(str -> str.startsWith("T")).
                                             peek(str -> System.out.println("After Filter: " + str));
          Stream<Integer> streamOfLength = startsWithT.map(str -> str.length());
          
          streamOfLength.forEach(System.out::println);
          
          Stream<String> names2 = Stream.of("Tim", "Tom", "Tim", "Tom", "Thomas");
          List<String> result = names2.distinct().collect(Collectors.toList());
          //names2.forEach(System.out::println);
  
          /*
          result.stream().
                 filter(str -> str.length() > 4).
                 map(str -> str + "sadshjkhaadhkjaskhj").
                 map(str -> str.substring(7)).
                 map(str -> str.length()).
                 forEach(System.out::println);
          
          */
          
          
          /*
          Stream<String> namesFilterQuestion = Stream.of("Tim", "Tom", "Peter", 
          // 10000, 
          "Mike", "Thomas");
          namesFilterQuestion.parallel()
                              filter(str -> str.startsWith("P")).
                              filter(___)
                              limit(20);        
*/
          
          
          
    }
}
