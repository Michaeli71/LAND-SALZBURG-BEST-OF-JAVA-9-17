package solutions.part2_bulk_operations;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise4_RemoveIf {

	public static void main(String[] args) {

	    final List<String> names = createNamesList(); 
		System.out.println(removeIf_External_Iteration(names));

		// a)
		final Predicate<String> isShortWord = str -> str.length() < 4;
		final Predicate<String> has7orMoreChars = str -> {
		    // Aktion 1
		    // Aktion 2
		    return str.length() >= 7;
		};
		final List<String> names1 = createNamesList(); 
        
		 // ... Performance leicht besser O(2 * n) => O(n)
		names1.removeIf(isShortWord);
        names1.removeIf(has7orMoreChars);
        // ... Performance leicht besser O(n)
        // final Predicate<String> myCombi = isShortWord.or(has7orMoreChars);
        names1.removeIf(isShortWord.or(has7orMoreChars));
        
        System.out.println("names1: " + names1);

        // b)
		final Predicate<String> lengthIsOdd = str -> str.length() % 2 != 0;
	    final List<String> names2 = createNamesList(); 
		names2.removeIf(lengthIsOdd);
		System.out.println(names2);		
		
		// c)
		// kein (direkter) Zugriff auf Index => man benutzt besser die klassische for-Schleife
	    final List<String> names3 = createNamesList(); 
	    final List<String> result = new ArrayList<>();
	    for (int i = 0; i <  names3.size(); i++)
	    {
	        if (i % 2 != 0) 
	            result.add(names3.get(i));
	    }
	    System.out.println(result);
	    
	    // Trick
	    final List<String> names4 = createNamesList(); 
	    final Predicate<String> posIsOdd = word -> names4.indexOf(word) % 2 != 0;
	    names4.removeIf(posIsOdd);
        System.out.println(names4);     
	}

	
	private static List<String> removeIf_External_Iteration(final List<String> names) 
	{		
		final Iterator<String> it = names.iterator();
		while (it.hasNext())
		{
			final String currentName = it.next();
			if (currentName.length() < 4)
			{
				it.remove();
			}
		}
		
		return names;
	}

	private static List<String> createNamesList() 
	{
		final List<String> names = new ArrayList<>();
        names.add("Michael");
        names.add("Tim");
        names.add("Andy");
        names.add("Flo");
        names.add("Yannis");
        names.add("Clemens");

		return names;
	}
}
