package solutions.part2_bulk_operations;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.function.UnaryOperator;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise5_ReplaceAll
{
    static final UnaryOperator<String> specialHighlighter = str -> {
        if (str.startsWith("M"))
        {
            return ">>" + str.toUpperCase() + "<<";
        }
        return str;
    };
    
    public static void main(final String[] args)
    {
        final List<String> names1 = createNamesList();
        System.out.println(replaceAll_External_Iteration(names1));
        
        // a)
        final List<String> names2 = createNamesList();
        System.out.println(replaceAll_Internal_Iteration(names2));
        
        // b)
        final List<String> names3 = createNamesList();
        System.out.println(replaceAll_Internal_Iteration2(names3));
    }

    private static List<String> replaceAll_External_Iteration(final List<String> names)
    {
        final ListIterator<String> it = names.listIterator();
        while (it.hasNext())
        {
            final String currentName = it.next();
            if (currentName.startsWith("M"))
            {
                it.set(">>" + currentName.toUpperCase() + "<<");
            }
        }

        return names;
    }
    
    private static List<String> replaceAll_Internal_Iteration(final List<String> names)
    {       
        names.replaceAll(specialHighlighter);

        return names;
    }

    private static List<String> replaceAll_Internal_Iteration2(final List<String> names)
    {
        final UnaryOperator<String> specialHighlighter = str -> {
            if (str.startsWith("M"))
            {
                return ">>" + str.toUpperCase() + "<<";
            }
            return str;
        };       
        final UnaryOperator<String> reverser = str -> {
            if (str.contains("i") || str.contains("I"))
            {
                return new StringBuilder(str).reverse().toString();
            }
            return str;
        };
        
        names.replaceAll(specialHighlighter);
        names.replaceAll(reverser);
        
        return names;
    }

    

    private static List<String> createNamesList()
    {
        final List<String> names = new ArrayList<>();
        names.add("Michael");
        names.add("Tim");
        names.add("Flo");
        names.add("Merten");
        return names;
    }

}
