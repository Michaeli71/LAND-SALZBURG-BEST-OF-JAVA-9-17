package solutions.part4_date_and_time;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2017 by Michael Inden
 */
public class PredefinedDateFormattingExample 
{
	public static void main(String[] args) 
	{
        final LocalDate date = LocalDate.now();
        System.out.println("original date:   " + date);

        final DateTimeFormatter formatter1 = DateTimeFormatter.BASIC_ISO_DATE;
        final DateTimeFormatter formatter2 = DateTimeFormatter.ISO_DATE;
        final DateTimeFormatter formatter3 = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);

        System.out.println("BASIC_ISO_DATE:  " + date.format(formatter1));;
        System.out.println("ISO_DATE:        " + date.format(formatter2));;
        System.out.println("ofLocalizedDate: " + date.format(formatter3));;
	}
}
