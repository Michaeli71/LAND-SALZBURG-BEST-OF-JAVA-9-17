package solutions.part4_date_and_time;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjuster;
import java.time.temporal.TemporalAdjusters;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise4_TemporalAdjusters 
{
	public static void main(final String[] args) 
	{		
		final LocalDate midOfMarch = LocalDate.of(2014, 3, 15);
		final TemporalAdjuster toFirstSunday = TemporalAdjusters.firstInMonth(DayOfWeek.SUNDAY);
		final TemporalAdjuster toLastSunday = TemporalAdjusters.lastInMonth(DayOfWeek.SUNDAY);
		final TemporalAdjuster toLastFriday = TemporalAdjusters.lastInMonth(DayOfWeek.FRIDAY);

		final LocalDate firstSunday = midOfMarch.with(toFirstSunday);
		final LocalDate lastSunday = midOfMarch.with(toLastSunday);
		final LocalDate lastFriday = midOfMarch.with(toLastFriday);

		System.out.println(firstSunday);
		System.out.println(lastSunday);
		System.out.println(lastFriday);
	}
}
