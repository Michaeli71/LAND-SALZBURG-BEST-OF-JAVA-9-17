package solutions.part3_streams_and_filter_map_reduce;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2017 by Michael Inden
 */
public class Exercise11_TakeDropWhileExample 
{
	public static void main(final String[] args) 
	{
		final Stream<Integer> numbers1 = Stream.of(1,2,3,4, 77, 88, 99, 1, 2);
		final Stream<Integer> numbers2  = Stream.of(1,2,3,4, 77, 88, 99, 1, 2);
		final Stream<Integer> numbers3  = Stream.of(1,2,3,4, 77, 88, 99, 1, 2);
		
		final Predicate<Integer> isBelow10 = n -> n < 10;
		
		System.out.println("takeWHile");
		final Stream<Integer> takeWhieResult = takeWhile(numbers1, isBelow10);
		takeWhieResult.forEach(System.out::println);
		
		System.out.println("dropWhile1");
		final Stream<Integer> dropWhieResult1 = dropWhile(numbers2, isBelow10);
		dropWhieResult1.forEach(System.out::println);
		
		System.out.println("dropWhile2");
		final Stream<Integer> dropWhieResult3 = dropWhileCorrected(numbers3, isBelow10);
		dropWhieResult3.forEach(System.out::println);
	}
	
	public static <T> Stream<T> takeWhile(final Stream<T> inputStream, final Predicate<? super T> predicate)
	{
		final List<T> elements = inputStream.collect(Collectors.toList());
		final List<T> result = new ArrayList<>();
		
		final Iterator<T> it = elements.iterator();
		while (it.hasNext())
		{
			final T current = it.next();
			if (predicate.test(current))
			{
				result.add(current);
			}
			else
			{
				break;
			}
		}
		
		return result.stream();
	}
	
	public static <T> Stream<T> dropWhile(final Stream<T> inputStream, final Predicate<? super T> predicate)
	{
		final List<T> elements = inputStream.collect(Collectors.toList());
		final List<T> result = new ArrayList<>();
		
		final Iterator<T> it = elements.iterator();
		while (it.hasNext())
		{
			final T current = it.next();
			if (predicate.test(current))
			{
				// skip entry
			}
			else
			{
				result.add(current);
			}
		}
		
		return result.stream();
	}
	
	public static <T> Stream<T> dropWhileCorrected(final Stream<T> inputStream, final Predicate<? super T> predicate)
	{
		final List<T> elements = inputStream.collect(Collectors.toList());
		final List<T> result = new ArrayList<>();
		
		final Iterator<T> it = elements.iterator();
		while (it.hasNext())
		{
			final T current = it.next();
			if (predicate.test(current))
			{
				// skip entry
			}
			else
			{
				result.add(current);
				break;
			}
		}
		
		it.forEachRemaining(element -> result.add(element));
		
		return result.stream();
	}
}
