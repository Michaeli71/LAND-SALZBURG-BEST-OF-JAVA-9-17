package solutions.part3_streams_and_filter_map_reduce;

import java.util.stream.Stream;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise7_ShowPipelineExampleStart
{
    public static void main(String[] args)
    {
        Stream.of("Andi", "Barbara", "Tom", "Carsten", "Mike", "Marius", "Micha", "Tim")
                        .filter(str -> str.length() > 4)
                        // ???
                        .map(str -> str.toUpperCase())      
                        // ???
                        .filter(str -> str.startsWith("M"))
                        // ???
                        .forEach(name -> System.out.println("forEach: " + name));
    }
}