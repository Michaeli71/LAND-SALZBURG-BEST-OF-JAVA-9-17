package solutions.part1_lambdas;

import java.io.IOException;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise8b_RunnableThatThrowsExample  
{
    public static void main(String[] args)
    {
        // Unhandled exception type IOException
        //final Runnable runner1 = () -> { System.out.println("RunnableThatThrows"); throw new IOException(); };
        //runner1.run();

        final Exercise8b_RunnableThatThrows runner2 = () -> { System.out.println("RunnableThatThrows"); throw new IOException(); };
        
        try
        {
            runner2.run();
        }
        catch (RuntimeException re)
        {
            System.out.println("Error excuting lambda: " + re.getCause());
        }
    }
}