package solutions.part1_lambdas;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise2_RunnableAsLambda 
{
	public static void main(final String[] args) 
	{
		// a)
		final Runnable runner = () -> System.out.println("I am the first lambda and say hello world");
		new Thread(runner).start();
		
		// b)
		final String messageText = "Mike";
		final Runnable runner2 = () -> System.out.println("I am the first lambda and say hello " + messageText);
		new Thread(runner2).start();
		
		final Runnable runner3 = provideTextOuptut("This is my message");
		new Thread(runner3).start();
	}
	
	private static Runnable provideTextOuptut(final String message)
	{
		return () -> System.out.println(message);
	}
}
