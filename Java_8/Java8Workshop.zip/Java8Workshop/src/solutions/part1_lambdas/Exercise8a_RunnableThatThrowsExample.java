package solutions.part1_lambdas;

import java.io.IOException;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise8a_RunnableThatThrowsExample  
{
    public static void main(final String[] args)
    {
        // Achtung: Nur unzureichend, dadurch kompiliert es, aber => IOException
        final Runnable runner1 = () -> 
        { 
        		try 
        		{
                	System.out.println("RunnableThatThrows"); 
                	throw new IOException(); 
        		}
        		catch (final IOException ioe)
        		{
        			throw new RuntimeException(ioe);
        		}
        };
        runner1.run();
    }
}