package part1;

import java.io.File;
import java.io.FileFilter;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise04_FileFilter
{
    public static void main(final String[] args)
    {
        final FileFilter direcoryFilter = new FileFilter()
        {
            @Override
            public boolean accept(final File pathname)
            {
                return pathname.isDirectory();
            }
        };

        final FileFilter direcoryFilterLambda = pathname -> pathname.isDirectory();
        final FileFilter direcoryFilterMethodRef = File::isDirectory;

        final FileFilter pdfFileFilter = new FileFilter()
        {
            @Override
            public boolean accept(final File pathname)
            {
                return (pathname.isFile() && pathname.getName().toLowerCase().endsWith(".pdf"));
            }
        };

        final FileFilter pdfFileFilterLambda = pathname -> (pathname.isFile()
                                                            && pathname.getName().toLowerCase().endsWith(".pdf"));
    }
}
