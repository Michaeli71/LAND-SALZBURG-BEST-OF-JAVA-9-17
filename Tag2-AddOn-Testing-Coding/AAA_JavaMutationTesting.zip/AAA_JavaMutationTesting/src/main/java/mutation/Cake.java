package mutation;

// https://blog.scottlogic.com/2017/09/25/mutation-testing.html
public class Cake
{
    private static final int MARGARINE_WEIGHT    = 100;

    private static final int COCOA_WEIGHT        = 25;

    private static final int EGG_COUNT           = 2;

    private static final int ORANGE_JUICE_VOLUME = 15;

    private int              cocoaWeight;

    private int              eggCount;

    private int              sugar;

    private int              margarineWeight;

    private int              flour;

    private int              orangeJuiceVolume;

    enum CakeType {
        CHOCOLATE, ORANGE, VICTORIA_SPONGE
    }

    // Vorweihnachtliches Kekse backen
    static Cake createCake(CakeType cakeType)
    {
        Cake cake = new Cake();
        cake.setMargarineWeight(MARGARINE_WEIGHT);
        cake.setSugar(MARGARINE_WEIGHT);
        cake.setEggCount(EGG_COUNT);

        if (CakeType.CHOCOLATE.equals(cakeType))
        {
            cake.setFlour(MARGARINE_WEIGHT - COCOA_WEIGHT);
            cake.setCocoaWeight(COCOA_WEIGHT);
        }
        else
        {
            cake.setFlour(MARGARINE_WEIGHT);
            if (CakeType.ORANGE.equals(cakeType))
            {
                cake.setOrangeJuiceVolume(ORANGE_JUICE_VOLUME);
            }
        }
        return cake;
    }

    public int getOrangeJuiceVolume()
    {
        return orangeJuiceVolume;
    }

    public void setOrangeJuiceVolume(int orangeJuiceVolume)
    {
        this.orangeJuiceVolume = orangeJuiceVolume;
    }

    public int getCocoaWeight()
    {
        return cocoaWeight;
    }

    public void setCocoaWeight(int cocoaWeight)
    {
        this.cocoaWeight = cocoaWeight;
    }

    public int getEggCount()
    {
        return eggCount;
    }

    public void setEggCount(int eggCount)
    {
        this.eggCount = eggCount;
    }

    public int getMargarineWeight()
    {
        return margarineWeight;
    }

    public void setMargarineWeight(int margarineWeight)
    {
        this.margarineWeight = margarineWeight;
    }

    public int getSugar()
    {
        return sugar;
    }

    public void setSugar(int sugar)
    {
        this.sugar = sugar;
    }

    public int getFlour()
    {
        return flour;
    }

    public void setFlour(int flour)
    {
        this.flour = flour;
    }

}
